#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
deps="$HOME/agent-ab-deps"
profile=stage1
mode=check

usage() {
    cat <<'HELP'
Usage: bash scripts/install.sh [--check|--setup] [--deps DIRECTORY] [--profile stage1|full] [-- PREFLIGHT_ARGS]
--check (default) inventories dependencies and prints install sources.
--setup creates the Agent-Ab environment, applies selected missing-tool recipes,
generates configs/site.json on first setup, and checks readiness.
HELP
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --deps) deps="${2:?--deps requires a directory}"; shift 2 ;;
        --profile) profile="${2:?--profile requires stage1 or full}"; shift 2 ;;
        --check) mode=check; shift ;;
        --setup) mode=setup; shift ;;
        --help|-h) usage; exit 0 ;;
        --) shift; break ;;
        *) usage >&2; exit 2 ;;
    esac
done
case "$profile" in
    stage1|full) ;;
    *) printf 'Unknown profile: %s\n' "$profile" >&2; exit 2 ;;
esac

base_python="${PYTHON3:-python3}"
"$base_python" -c 'import sys; assert (3, 9) <= sys.version_info[:2] <= (3, 12), "Use Python 3.9–3.12"'
deps="$("$base_python" -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).expanduser().resolve())' "$deps")"
report="$ROOT/.setup-report"
site="$ROOT/configs/site.json"
if [[ "$mode" == check ]]; then
    for arg in "$@"; do
        case "$arg" in
            --apply|--apply=*|--write-site|--write-site=*)
                printf '%s requires --setup.\n' "$arg" >&2
                exit 2 ;;
        esac
    done
    if [[ ! -f "$site" ]]; then site="$ROOT/configs/site.template.json"; fi
    exec "$base_python" "$ROOT/skills/agent-ab-portable/scripts/preflight.py" \
        --project "$ROOT" --site "$site" --search "$deps" --search "$deps/conda" \
        --map /opt/agent-ab/deps "$deps" --verify --report-dir "$report" "$@"
fi
mkdir -p "$deps"
python="$ROOT/.venv/bin/python"
if [[ ! -x "$python" ]]; then
    "$base_python" -m venv "$ROOT/.venv"
fi
if ! "$python" -c 'import numpy; assert numpy.__version__ == "1.26.4"' 2>/dev/null; then
    "$python" -m pip install --only-binary=:all: -r "$ROOT/requirements.txt"
fi

mkdir -p "$report"
candidate="$site"
site_args=(--site "$site")
if [[ ! -f "$site" ]]; then
    staging="$(mktemp -d "$report/site.XXXXXX")"
    candidate="$staging/site.json"
    trap 'rm -f -- "$candidate"; rmdir -- "$staging"' EXIT
    site_args=(--site "$ROOT/configs/site.template.json" --write-site "$candidate")
fi
"$python" "$ROOT/skills/agent-ab-portable/scripts/preflight.py" \
    --project "$ROOT" "${site_args[@]}" --search "$deps" --search "$deps/conda" \
    --map /opt/agent-ab/deps "$deps" --verify --report-dir "$report" "$@"

"$python" - "$report/software-inventory.json" "$candidate" "$profile" <<'CHECK'
import json
from pathlib import Path
import sys

report, site = [json.loads(Path(name).read_text(encoding="utf-8")) for name in sys.argv[1:3]]
required = ["ppiflow", "abmpnn", "flowpacker", "protenix", "ipsae"]
if sys.argv[3] == "full":
    required.append("rosetta")
    if site["tools"]["iggm"].get("automatic", {}).get("enabled"):
        required.append("iggm")
issues = {tool: report["tools"][tool]["missing"] for tool in required if report["tools"][tool]["missing"]}
if issues:
    for tool, missing in issues.items():
        print(tool + " missing: " + ", ".join(missing), file=sys.stderr)
    raise SystemExit("See .setup-report/software-inventory.md and docs/INSTALL.md")
CHECK

AGENT_AB_PYTHON="$python" bash "$ROOT/scripts/agent-ab" --site-config "$candidate" doctor
if [[ "$candidate" != "$site" ]]; then
    ln -- "$candidate" "$site"
    printf 'Created %s\n' "$site"
fi
