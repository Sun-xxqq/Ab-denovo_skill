# 在新的 Linux 服务器部署 Agent-Ab

## 软件与获取方式

准备带可用 NVIDIA 驱动的 Linux 主机，确保 `nvidia-smi` 可用，并安装 Bash、Git 和带 `venv` 的 Python 3.9–3.12。PPIFlow 的 CUDA、编译工具和内存要求以所选 upstream 版本为准。各模型环境分开构建，项目自己的 `.venv` 用于启动与预检。

| 依赖 | 安装及验证入口 |
| --- | --- |
| Agent-Ab Python | `scripts/install.sh` 自动创建 `.venv` 并安装 `requirements.txt` 中的 NumPy。 |
| PPIFlow、AbMPNN、FlowPacker | 按 [PPIFlow 官方安装说明](https://github.com/Mingchenchen/PPIFlow#environment-and-installation) 准备源码、GPU 环境和模型。其上游提供 `Install.sh`。按实际版本确认 `pipeline.py`、`tools/AbMPNN/`、`tools/flowpacker/` 和 `weigths/`（原版拼写）的内容。 |
| Protenix | 依照 [Protenix 官方文档](https://github.com/bytedance/Protenix/blob/main/docs/training_inference_instructions.md) 在独立环境安装。站点模板使用 `protenix_mini_esm_v0.5.0`，需要相应 checkpoint 和可读的 common 数据目录。 |
| ipSAE | 取自 [官方仓库](https://github.com/DunbrackLab/IPSAE)，预检查找 `ipsae.py`。 |
| Rosetta 与 PyRosetta | 按所选计算阶段取得适用的软件及授权。[Rosetta Commons](https://rosettacommons.org/) · [PyRosetta](https://www.pyrosetta.org/) |
| IgGM | 完整任务按站点启用条件安装 [IgGM](https://github.com/TencentAI4S/IgGM) 和其 checkpoint。模板中的 `required_paths` 表明当前流水线预期的文件名。 |
| AF3Score、DockQ | 使用到这些分支时核对 AlphaFold 3 数据和参数、以及 `DockQ --help`。权重与数据库依 [AlphaFold 3 官方说明及条款](https://github.com/google-deepmind/alphafold3) 获取。 |

使用与 Agent-Ab 适配器相容的工具版本。原服务器上的外部工具目录未留下可核实的源码提交，因此上游最新版的接口兼容性需要实机验收。保留团队取得的来源版本、条件及文件校验和，便于复现。

## 首次配置

先运行 `bash scripts/install.sh --check`。检测结果列在终端和 `.setup-report/software-inventory.md`，缺项会附上获取链接。

默认搜索 `$HOME/agent-ab-deps`，可用 `--deps` 更换。遵循以下布局时，可直接用站点模板推导路径：

```text
agent-ab-deps/
├── PPIFlow/
├── Protenix/
├── IPSAE/
├── IgGM/                       # 按完整任务的实际开关准备
├── conda/envs/
│   ├── ppiflow_af3/
│   └── protenix/
├── conda-envs/IgGM/            # 或用 locations 指定原环境
└── protenix-data/
    ├── common/
    └── checkpoint/
```

已有安装采用其他路径时，复制 `configs/locations.example.json`，填写实际目录和环境。

```bash
bash scripts/install.sh --setup --deps "$HOME/agent-ab-deps" -- \
  --locations configs/locations.json
```

自定义已授权的安装来源时，可把其安装命令放入 `recipes.json`。安装器仅对指定的缺项执行配方，结束后重新探测。配方的 `cwd` 为工作目录，`commands` 为 argv 列表。团队离线包可先执行 `sha256sum --check CHECKSUM_FILE`，再解包到指定的空目录。获取第三方受授权资源的步骤由操作者在各自渠道完成。

```bash
bash scripts/install.sh --setup --profile full --deps "$HOME/agent-ab-deps" -- \
  --locations configs/locations.json \
  --recipes configs/recipes.json --apply ppiflow protenix ipsae iggm
```

预检结果写入 `.setup-report/software-inventory.md`。`site.json` 已存在时会复用该文件，在新位置部署可从模板重新生成一份。优先检查 PPIFlow 与模型路径、Protenix 数据、运行目录和 GPU。部署安装器不启动设计计算。

站点模板面向通用任务，默认关闭项目专用负靶筛选。运行需要负靶的 `full` 任务时，通过 spec 或站点配置提供实际负靶结构、链和适用的筛选参数，并核对 IgGM 与 Stage 3 开关。

## 运行上游示例

`make-example.py` 从本地 PPIFlow 安装读取其文档使用的 IL‑13 及纳米抗体 framework 结构，创建一份 Stage 1 spec。它适用于验证工具联通和输出布局，完整任务仍需按 `full` 的实际分支验收。

```bash
.venv/bin/python scripts/make-example.py --output example-task.json
bash scripts/agent-ab validate example-task.json
bash scripts/agent-ab plan example-task.json
bash scripts/agent-ab pipeline RUN_ID --dry-run
bash scripts/agent-ab pipeline RUN_ID --gpu auto
bash scripts/agent-ab status RUN_ID
bash scripts/agent-ab parts RUN_ID --tail 30
```

从 `plan` 输出读取 `RUN_ID`。若流程要求 Top‑N，按排序表和允许范围选择，再用 `select-backbones RUN_ID TOP_N` 记录并继续。以状态、实际产物和筛选表核对完成情况，零候选终止也记录其结束原因。

## 验收范围

- 已在隔离的 Linux 目录验证。新解包时，`--check` 报告缺项和来源，未创建虚拟环境或站点配置。
- 复用服务器既有外部模型工具时，`--setup` 成功创建新的项目虚拟环境、生成站点配置并通过 `doctor`。
- 使用上游 IL‑13 示例，`validate`、`plan`、`pipeline --dry-run`、`status` 和 `parts` 均通过。
- 独立服务器从零配置全部第三方工具后的 GPU 实跑仍待验收。验收时用实际状态与结果文件核对示例，并用 `full` spec 验证已启用的 Stage 2、IgGM 和 Stage 3。
