---
name: agent-ab-portable
description: "为另一台 Linux 服务器部署或检查 Agent-Ab，优先复用已安装的软件、环境和权重，配置已授权的缺项，生成站点配置与逐工具软件盘点。也可单独盘点 ProteinMPNN soluble 和 FoldX。"
---

# Agent-Ab 异机预检与配置

在实际运行 Agent-Ab 的 Linux 服务器上执行 [scripts/preflight.py](scripts/preflight.py)。在本地通过 SSH 调用时，第二位操作者提供自己的账户、项目路径和软件搜索路径。

1. 先盘点。用 `--project` 指向对方服务器上的项目，传入可用的 `--site` 和一个或多个 `--search`。脚本从显式配置、常用目录、已知环境目录及适用的 PATH 入口查找依赖。加 `--sizes --verify --report-dir DIR` 输出截图式 Markdown 与 JSON。只有盘点需求时，到此交付。
2. 按实际任务确认依赖。固定流程的核心是 PPIFlow、AbMPNN、FlowPacker、Protenix、ipSAE，以及当前任务启用的 Rosetta、IgGM 和后续筛选。查询点和子工具见 [references/tools.json](references/tools.json)。独立的 ProteinMPNN soluble 与 FoldX 是额外盘点项。
3. 复用已通过验证的安装。缺少软件时，用操作者已确认且有权使用的、版本明确的安装包或安装配方执行 [配置说明](references/deployment.md) 中的 `--apply`。缺少来源、许可、权重、环境或数据时，在报告中列出具体缺项。已有但不完整的安装保留，使用明确的新路径修复。
4. 使用 `--write-site` 从已有站点配置生成新文件。确认报告中的旧绝对路径、入口状态、软件版本和 GPU。配置生成后读取 [固定流程入口](references/deployment.md)，在新环境跑 `doctor` 和无 GPU 的帮助检查。
5. 用户委托实际设计时，再执行现有 `plan` / `pipeline` / `status` / `parts` 工作流。使用原任务 spec、科学参数和候选编号。Top-N 等必填设计输入使用用户给定或已记录的值。报告实际检查层级，区分文件、命令、GPU 和完整任务。

源服务器盘点供迁移比对。第二台服务器的可用性以它自己的预检与实验运行状态为准。
