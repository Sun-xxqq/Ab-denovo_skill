---
name: agent-ab-workflow
description: "按已定参数运行或续跑 Agent-Ab 的固定 Pipeline，核对候选结构、序列和筛选结果。适用于按原流程执行设计任务、继续已有 run 或查询实际进度。"
---

# Agent-Ab 固定 Pipeline

通过服务器项目的 `scripts/agent-ab` 执行固定流程。项目路径、命令和各阶段的核对方法见 [执行参考](references/execution.md)。独立的研究 Agent 入口用于隔离的 Stage 1 研究任务。

1. **确定任务。** 已有任务以 `run_id` 和保存的 `spec.json` 为准。新任务确认靶标结构与链、hotspot、framework、设计类型、计算参数和运行范围，再执行 `validate`、`plan`。
2. **按已定参数执行。** 使用 `pipeline` 和任务已有的配置、软件、筛选门槛与原始候选编号。范围为 `full` 时，按项目配置推进实际启用的后续步骤。仅查进度时使用 `status`、`parts`。
3. **按实际状态处理暂停。** 读取 `action_required`。需要 Top‑N 时，使用用户已给出或已记录的选择。缺少必要输入时给出排序表、可选范围和缺项，待用户提供后用同一 `run_id` 继续。
4. **交付实际结果。** 核对状态、manifest、筛选表与 `result_paths`。报告实际终点、确认的候选数量、原编号输出路径和暂停或失败原因。零候选也按流程的实际终止状态交付。

沿用任务已定的 hotspot、framework、seed、采样策略和阈值。执行计算以用户请求为准，整理 Skill 或检查配置时使用只读命令与 `--dry-run`。
